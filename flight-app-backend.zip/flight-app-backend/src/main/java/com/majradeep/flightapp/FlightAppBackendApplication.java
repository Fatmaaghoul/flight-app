package com.majradeep.flightapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightAppBackendApplication.class, args);
	}

}
